namespace Rauch.Plugins.Install;

[Name("office")]
[Description("Download and install Microsoft Office")]
public class Office : ICommand
{
    const string DOWNLOAD_URL = "https://cloud.it-guards.at/download/OInstall_x64.exe";
    const string INSTALL_DIR = @"data\Office";
    const string FILE_NAME = "OInstall_x64.exe";

    [OS("windows")]
    public async Task ExecuteAsync(string[] args, IServiceProvider services, CancellationToken ct)
    {
        var logger = services.GetService<ILogger>();

        try
        {
            if (!EnsureAdministrator(logger))
            {
                return;
            }

            SetWorkingDirectory(INSTALL_DIR, logger);

            await DownloadFile(DOWNLOAD_URL, FILE_NAME, logger, ct);

            _ = StartProcess(FILE_NAME, logger: logger);
        }
        catch (Exception ex)
        {
            logger?.Error($"Failed: {ex.Message}");
        }
    }
}
