namespace Rauch.Plugins.Windows;

[Command("windows", IsGroup = true)]
public class _Index : BaseCommandGroup
{
}
