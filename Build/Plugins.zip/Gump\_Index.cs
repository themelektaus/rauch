namespace Rauch.Plugins.Gump;

[Command("gump", IsGroup = true)]
public class _Index : BaseCommandGroup
{
}
