namespace Rauch.Plugins.Outlook;

[Command("outlook", IsGroup = true)]
public class _Index : BaseCommandGroup
{
}
