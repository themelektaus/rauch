namespace Rauch.Plugins.Run;

[Command("run", IsGroup = true)]
public class _Index : BaseCommandGroup
{
}
