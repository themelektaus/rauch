namespace Rauch.Plugins.Install;

[Command("install", IsGroup = true)]
public class _Index : BaseCommandGroup
{
}
