namespace Rauch.Plugins.Office;

[Command("office", IsGroup = true)]
public class _Index : BaseCommandGroup
{
}
