namespace Rauch.Plugins.Uninstall;

[Command("uninstall", IsGroup = true)]
public class _Index : BaseCommandGroup
{
}
